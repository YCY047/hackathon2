# hackathon2
REKOGNITION_MODEL_ARN=arn:aws:rekognition:us-west-2:407187906123:project/cluture/version/cluture.2025-04-26T14.38.53/1745649534261
AWS_REGION="us-west-2"
AWS_ACCESS_KEY_ID="AKIAV5TSKLZF4VWSX25A"
AWS_SECRET_ACCESS_KEY="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"
BUCKET_NAME=culture3
PROJECT_VERSION_ARN=arn:aws:rekognition:us-west-2:407187906123:project/cluture/version/cluture.2025-04-26T14.38.53/1745649534261
AWS_SESSION_TOKEN="IQoJb3JpZ2luX2VjELH//////////wEaCXVzLWVhc3QtMSJHMEUCIQC/Fnf5Tu3ifyYZdIMkItFSU4+Txs4y+UOzZcYjXztpfAIgLPFsR2fj5o99CxN1gr/0PkkSpDdA5ZMRGEqy6Ks2+bsqmQIIShABGgw0MDcxODc5MDYxMjMiDAI2r/lbjqDvk9G7cSr2AZAL0ocv2E/cS4UsRxFkHA3Ih1hLvp0nze3iamitH7WjhCgEArzX1Jt99OVobm4kSIKGira3CNh7FJZwyKNEA8AVahYaUiT1HC/sFH5t3b1SKwF/a+W+HFwmf/tDeJVg5YCFxJZjrXRi66DtgpryqJOuNbKvxEvB0RpJFXjDjMvE/hQYr5dQuUvIy5PCNnrR7DFvcpXMetSTvP8JqEcB6fRqRPFp8uWdq+DkK9OBkDOnjNuOTe3m4bMXbxGCeGNb3o2k0VxXjourTgJ7N8faX73NvAqfsyuEqthGXssgNUe/XsZ1ISnMBkrprre/A0n6Udch5EdGoTCBnrTABjqdAb7Jrn1Wu2y005HtJ4zZr9Ls7bTSVqGg5FAe05SCGBb9TgKS/yV8N52sEcVzkiPS7dF0LJvTOzw+kWrR9MIyAX67e2X8Hqa2Nysw7FzTYkUZXn6IgfNDHJWCWapO6VlsdPisOWzX/QjE8gk5R+PiaDayM6WLkBgOyqFihi/IOdwLBwe/ufwvfzTUR2bU9H0nvcFyv+TUE1LzHHGS9ts="

git add<file>{
    ![alt text](image.png)
![alt text](image-1.png)
![alt text](image-2.png)
![alt text](image-3.png)
![alt text](image-4.png)
![alt text](image-5.png)

}
